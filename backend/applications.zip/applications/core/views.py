from decimal import Decimal

from django.db.models import Q, Sum

from rest_framework import status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from applications.finanzas.models import (
    CategoriaFinanciera,
    CuentaFinanciera,
    GrupoFinanciero,
    MovimientoFinanciero,
)

from applications.finanzas.permissions import (
    EsFinanzas,
)

from applications.finanzas.serializers import (
    CategoriaFinancieraSerializer,
    CuentaFinancieraSerializer,
    GrupoFinancieroSerializer,
    MovimientoFinancieroSerializer,
    calcular_saldo_actual,
)


# ============================================================
# BASE
# ============================================================


class FinanzasBaseViewSet(
    ModelViewSet
):

    permission_classes = [
        IsAuthenticated,
        EsFinanzas,
    ]

    def perform_create(
        self,
        serializer,
    ):
        serializer.save(
            user_made=self.request.user,
            user_updated=self.request.user,
        )

    def perform_update(
        self,
        serializer,
    ):
        serializer.save(
            user_updated=self.request.user,
        )

    def perform_destroy(
        self,
        instance,
    ):
        instance.is_deleted = True
        instance.user_deleted = (
            self.request.user
        )

        instance.save()


# ============================================================
# GRUPOS
# ============================================================


class GrupoFinancieroViewSet(
    FinanzasBaseViewSet
):

    serializer_class = (
        GrupoFinancieroSerializer
    )

    def get_queryset(self):

        queryset = (
            GrupoFinanciero.objects
            .filter(
                is_deleted=False,
            )
            .order_by(
                "nombre",
            )
        )

        activo = (
            self.request.query_params
            .get("activo")
        )

        tipo = (
            self.request.query_params
            .get("tipo")
        )

        if activo is not None:

            if activo.lower() == "true":
                queryset = queryset.filter(
                    activo=True,
                )

            elif activo.lower() == "false":
                queryset = queryset.filter(
                    activo=False,
                )

        if tipo:
            queryset = queryset.filter(
                tipo=tipo,
            )

        return queryset


# ============================================================
# CATEGORIAS
# ============================================================


class CategoriaFinancieraViewSet(
    FinanzasBaseViewSet
):

    serializer_class = (
        CategoriaFinancieraSerializer
    )

    def get_queryset(self):

        queryset = (
            CategoriaFinanciera.objects
            .filter(
                is_deleted=False,
            )
            .select_related(
                "grupo",
            )
            .order_by(
                "grupo__nombre",
                "nombre",
            )
        )

        grupo = (
            self.request.query_params
            .get("grupo")
        )

        activo = (
            self.request.query_params
            .get("activo")
        )

        tipo = (
            self.request.query_params
            .get("tipo")
        )

        if grupo:
            queryset = queryset.filter(
                grupo_id=grupo,
            )

        if tipo:
            queryset = queryset.filter(
                grupo__tipo__in=[
                    tipo,
                    GrupoFinanciero.Tipo.MIXTO,
                ]
            )

        if activo is not None:

            if activo.lower() == "true":
                queryset = queryset.filter(
                    activo=True,
                    grupo__activo=True,
                )

            elif activo.lower() == "false":
                queryset = queryset.filter(
                    activo=False,
                )

        return queryset


# ============================================================
# CUENTAS
# ============================================================


class CuentaFinancieraViewSet(
    FinanzasBaseViewSet
):

    serializer_class = (
        CuentaFinancieraSerializer
    )

    def get_queryset(self):

        queryset = (
            CuentaFinanciera.objects
            .filter(
                is_deleted=False,
            )
            .order_by(
                "nombre",
            )
        )

        activa = (
            self.request.query_params
            .get("activa")
        )

        tipo = (
            self.request.query_params
            .get("tipo")
        )

        if activa is not None:

            if activa.lower() == "true":
                queryset = queryset.filter(
                    activa=True,
                )

            elif activa.lower() == "false":
                queryset = queryset.filter(
                    activa=False,
                )

        if tipo:
            queryset = queryset.filter(
                tipo=tipo,
            )

        return queryset

    # --------------------------------------------------------
    # SALDO
    # --------------------------------------------------------

    @action(
        detail=True,
        methods=["get"],
        url_path="saldo",
    )
    def saldo(
        self,
        request,
        pk=None,
    ):

        cuenta = self.get_object()

        saldo = calcular_saldo_actual(
            cuenta
        )

        return Response({
            "cuenta": {
                "id": cuenta.id,
                "nombre": cuenta.nombre,
                "tipo": cuenta.tipo,
                "tipo_display": (
                    cuenta.get_tipo_display()
                ),
            },
            "saldo_inicial": (
                cuenta.saldo_inicial
            ),
            "saldo_actual": saldo,
        })

    # --------------------------------------------------------
    # MOVIMIENTOS DE LA CUENTA
    # --------------------------------------------------------

    @action(
        detail=True,
        methods=["get"],
        url_path="movimientos",
    )
    def movimientos(
        self,
        request,
        pk=None,
    ):

        cuenta = self.get_object()

        movimientos = (
            MovimientoFinanciero.objects
            .filter(
                is_deleted=False,
            )
            .filter(
                Q(
                    cuenta_origen=cuenta
                )
                |
                Q(
                    cuenta_destino=cuenta
                )
            )
            .select_related(
                "categoria",
                "categoria__grupo",
                "cuenta_origen",
                "cuenta_destino",
            )
            .order_by(
                "-fecha",
                "-id",
            )
        )

        serializer = (
            MovimientoFinancieroSerializer(
                movimientos,
                many=True,
            )
        )

        return Response({
            "cuenta": (
                CuentaFinancieraSerializer(
                    cuenta
                ).data
            ),
            "movimientos": (
                serializer.data
            ),
        })


# ============================================================
# MOVIMIENTOS
# ============================================================


class MovimientoFinancieroViewSet(
    FinanzasBaseViewSet
):

    serializer_class = (
        MovimientoFinancieroSerializer
    )

    def get_queryset(self):

        queryset = (
            MovimientoFinanciero.objects
            .filter(
                is_deleted=False,
            )
            .select_related(
                "categoria",
                "categoria__grupo",
                "cuenta_origen",
                "cuenta_destino",
            )
            .order_by(
                "-fecha",
                "-id",
            )
        )

        # ----------------------------------------------------
        # FILTROS
        # ----------------------------------------------------

        tipo = (
            self.request.query_params
            .get("tipo")
        )

        categoria = (
            self.request.query_params
            .get("categoria")
        )

        grupo = (
            self.request.query_params
            .get("grupo")
        )

        cuenta = (
            self.request.query_params
            .get("cuenta")
        )

        fecha_desde = (
            self.request.query_params
            .get("fecha_desde")
        )

        fecha_hasta = (
            self.request.query_params
            .get("fecha_hasta")
        )

        buscar = (
            self.request.query_params
            .get("buscar")
        )

        if tipo:
            queryset = queryset.filter(
                tipo=tipo,
            )

        if categoria:
            queryset = queryset.filter(
                categoria_id=categoria,
            )

        if grupo:
            queryset = queryset.filter(
                categoria__grupo_id=grupo,
            )

        if cuenta:
            queryset = queryset.filter(
                Q(
                    cuenta_origen_id=cuenta
                )
                |
                Q(
                    cuenta_destino_id=cuenta
                )
            )

        if fecha_desde:
            queryset = queryset.filter(
                fecha__gte=fecha_desde,
            )

        if fecha_hasta:
            queryset = queryset.filter(
                fecha__lte=fecha_hasta,
            )

        if buscar:
            queryset = queryset.filter(
                Q(
                    descripcion__icontains=buscar
                )
                |
                Q(
                    observacion__icontains=buscar
                )
            )

        return queryset

    # --------------------------------------------------------
    # RESUMEN
    # --------------------------------------------------------

    @action(
        detail=False,
        methods=["get"],
        url_path="resumen",
    )
    def resumen(
        self,
        request,
    ):

        queryset = self.get_queryset()

        ingresos = (
            queryset
            .filter(
                tipo=(
                    MovimientoFinanciero
                    .Tipo
                    .INGRESO
                )
            )
            .aggregate(
                total=Sum("monto")
            )["total"]
            or Decimal("0.00")
        )

        gastos = (
            queryset
            .filter(
                tipo=(
                    MovimientoFinanciero
                    .Tipo
                    .GASTO
                )
            )
            .aggregate(
                total=Sum("monto")
            )["total"]
            or Decimal("0.00")
        )

        transferencias = (
            queryset
            .filter(
                tipo=(
                    MovimientoFinanciero
                    .Tipo
                    .TRANSFERENCIA
                )
            )
            .aggregate(
                total=Sum("monto")
            )["total"]
            or Decimal("0.00")
        )

        resultado = (
            ingresos
            - gastos
        )

        return Response({
            "ingresos": ingresos,
            "gastos": gastos,
            "resultado": resultado,

            # Informativo solamente.
            # No afecta el resultado.
            "transferencias": (
                transferencias
            ),
        })